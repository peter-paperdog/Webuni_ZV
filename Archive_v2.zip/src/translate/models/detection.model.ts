export class Detection{
  confidence: number;
  language: string;
}
