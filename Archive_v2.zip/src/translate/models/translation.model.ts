export class Translation{
  q: string;
  translatedText: string;
}
